//
//  WittyFeedSDKLoaderCell.swift
//  wittyfeed_ios_api
//
//  Created by Sudama Dewda on 17/02/18.
//  Copyright © 2018 wittyfeed. All rights reserved.
//

import UIKit

class WittyFeedSDKLoaderCell: UICollectionViewCell {

    @IBOutlet weak var loaderActivity: UIActivityIndicatorView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
