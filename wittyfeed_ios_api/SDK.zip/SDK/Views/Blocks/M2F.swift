//
//  M2F.swift
//  wittyfeed_ios_sdk
//
//  Created by Sudama Dewda on 29/12/17.
//  Copyright © 2017 Vatsana Technologies. All rights reserved.
//

import UIKit

class M2F: UICollectionViewCell {
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var filler1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var filler2: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
