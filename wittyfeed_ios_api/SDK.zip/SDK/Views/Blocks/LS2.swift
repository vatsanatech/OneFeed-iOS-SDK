//
//  LS2.swift
//  wittyfeed_ios_sdk
//
//  Created by Sudama Dewda on 29/12/17.
//  Copyright © 2017 Vatsana Technologies. All rights reserved.
//

import UIKit

class LS2: UICollectionViewCell {
    @IBOutlet weak var view_large: UIView!
    @IBOutlet weak var view_s1: UIView!
    @IBOutlet weak var view_s2: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
