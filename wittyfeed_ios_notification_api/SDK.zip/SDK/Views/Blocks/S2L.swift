//
//  S2L.swift
//  wittyfeed_ios_sdk
//
//  Created by Vatsana Technologies on 29/12/17.
//  Copyright © 2017 Vatsana Technologies. All rights reserved.
//

import UIKit

class S2L: UICollectionViewCell {
    @IBOutlet weak var view_s1: UIView!
    @IBOutlet weak var view_s2: UIView!
    @IBOutlet weak var view_large: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
